from program10 import main as pgm10

pgm10()
